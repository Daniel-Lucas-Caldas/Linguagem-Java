import java.util.Scanner;

public class Main{
	public static void main(String[]args){
		Scanner scan = new Scanner(System.in);
		
        System.out.println("Digite a 1ª nota: ");
		int nota01 = scan.nextInt();
		
		System.out.println("Digite a 2ª nota: ");
		int nota02 = scan.nextInt();
		
		System.out.println("Digite a 3ª nota: ");
		int nota03 = scan.nextInt();
		
		int soma = nota01 + nota02 + nota03;
		float media = soma / 3;
		
		System.out.println("A média do aluno é: \n" + media);
		
		if (media >= 7) {
		    System.out.println("O aluno foi aprovado sem recuperação \n");
		} else if (media < 7 || media > 4) {
		    System.out.println("O aluno foi reprovado com direito a recuperação \n");
		} else if (media < 4) {
		    System.out.println("O aluno foi reprovado sem direito a prova de recuperação \n");
		}
		
		scan.close();
	}
}