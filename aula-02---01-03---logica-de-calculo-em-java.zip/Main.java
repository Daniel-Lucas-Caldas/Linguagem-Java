
public class Main {
	public static void main (String[]args){
		float Val1 = 10;
		float Val2 = 20;
		float res;
		res = Val1 + Val2; 
		System.out.println(res);
	}
}
