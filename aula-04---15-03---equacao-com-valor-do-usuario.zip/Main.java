import java.util.Scanner;

public class Main{
	public static void main(String[]args){
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Escolha o valor de X da 1ª operação: X - 2X + 3X - 4X \n");
		System.out.println("Escolha o valor de X da 2ª operação: 2X + 4X - 3X - 8X - 4X \n");
		
		System.out.println("Digite o 1ª valor a ser utilizado: ");
		int num1 = scan.nextInt();
		
		System.out.println("Digite o 2ª valor a ser utilizado: ");
		int num2 = scan.nextInt();
		 
		float operacao01 = num1 - (2 * num1) + (3 * num1) - (4 * num1);
		float operacao02 = (2 * num2) + (4 * num2) - (3 * num2) - (8 * num2) - (4 * num2);
		
		System.out.println("Resultado da 1ª operação: \n" + operacao01);
		System.out.println("Resultado da 2ª operação: \n" + operacao02);
		
		scan.close();
	   }
	}