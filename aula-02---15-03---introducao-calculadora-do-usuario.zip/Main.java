import java.util.Scanner;

public class Main{
	public static void main(String[]args){
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o primeiro valor: ");
		int Val01 = scan.nextInt();
		
		System.out.println("Digite o segundo valor: \n\n");
		int Val02 = scan.nextInt();
		
		int soma = Val01 + Val02;
		int subtracao = Val01 - Val02;
		int multiplicacao = Val01 * Val02;
		float divisao = Val01 / Val02;
		
		System.out.println("Resultado da soma: \n" + soma);
		System.out.println("Resultado da subtracao: \n" + subtracao);
		System.out.println("Resultado da multiplicacao: \n" + multiplicacao);
		System.out.println("Resultado da divisao: \n" + divisao);
		
		scan.close();
	}
}
