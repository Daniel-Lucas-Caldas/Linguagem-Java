/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
	public static void main(String[] args) {
		String Produto01 = "Processador Cyrux";
		float Mes01 = 500;
		float Mes02 = 600;
		float Mes03 = 1000;
		float TR01 = 7;
		float LR01 = 60;
		float EA01 = 100;
		float VMD01 = ((Mes01 + Mes02 + Mes03)/3)/25;
		float EMIN01 = (VMD01 * TR01);
		float EMAX01 = (LR01 + EMIN01);
		
		System.out.println("Procesador Cyrux");
		System.out.printf("O resultado da venda media diaria: %.2f \n", VMD01);
		System.out.printf("O resultado do estoque minimo: %.2f \n", EMIN01);
		System.out.printf("O resultado do estoque maximo: %.2f \n\n", EMAX01);
		
		if (EA01 < EMIN01) {
		    System.out.println("Pode comprar \n");
		} else {
		    System.out.println("Não comprar \n");
		}
		
		String Produto02 = "Processador Inter core";
		float mEs01 = 100;
		float mEs02 = 100;
		float mEs03 = 100;
		float TR02 = 5;
		float LR02 = 50;
		float EA02 = 70; 
		float VMD02 = ((mEs01 + mEs02 + mEs03)/3)/25;
		float EMIN02 = (VMD02 * TR02);
		float EMAX02 = (LR02 + EMIN02);
		
		System.out.println("Procesador Inter core");
		System.out.printf("O resultado da venda media diaria: %.2f \n", VMD02);
		System.out.printf("O resultado do estoque minimo: %.2f \n", EMIN02);
		System.out.printf("O resultado do estoque maximo: %.2f \n\n", EMAX02);
		
		if (EA02 < EMIN02) {
		    System.out.println("Pode comprar \n");
		} else {
		    System.out.println("Não comprar \n");
		}

		String Produto03 = "Processador AMD";
		float meS01 = 250;
		float meS02 = 350;
		float meS03 = 450;
		float TR03 = 9;
		float LR03 = 100;
		float EA03 = 80; 
		float VMD03 = ((meS01 + meS02 + meS03)/3)/25;
		float EMIN03 = (VMD03 * TR03);
		float EMAX03 = (LR03 + EMIN03);
		
		System.out.println("Procesador AMD");
	    System.out.printf("O resultado da venda media diaria: %.2f \n", VMD03);
		System.out.printf("O resultado do estoque minimo: %.2f \n", EMIN03);
		System.out.printf("O resultado do estoque maximo: %.2f \n\n", EMAX03);
		
		if (EA03 < EMIN03) {
		    System.out.println("Pode comprar \n");
		} else {
		    System.out.println("Não comprar \n");
		}
		
		
	
	}
}
